package ro.teamnet.zth.fmk.domain;

/**
 * Created by Alexandru.Bottea on 7/20/2017.
 */
public enum HttpMethod {
    GET,
    POST,
    PUT,
    DELETE
}
